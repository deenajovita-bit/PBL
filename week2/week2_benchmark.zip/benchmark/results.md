# Benchmark results

Workload: 100000 commands per run (LOAD, ADD, PUSH, POP, STORE repeated), average of 3 runs.

| Metric | Standalone (1 process) | Multi-process (UI + Core + Logger) |
|---|---|---|
| Total time for 100000 commands (ms) | 26.97 | 784.33 |
| Average time per command (us) | 0.22 | 7.77 |
| Median (p50) per command (us) | 0.20 | 7.34 |
| p95 per command (us) | 0.23 | 11.63 |
| p99 per command (us) | 0.27 | 21.18 |
| Total CPU time (ms) | 37.06 | 779.11 |
| Peak memory, all processes (KB) | 3106.67 | 6981.33 |

**IPC overhead per command:** 7.55 us (7.77 - 0.22). The multi-process version is about 35.3x slower per command.

## Multi-process breakdown (average)

| Process | IPC | CPU time (ms) | Peak memory (KB) |
|---|---|---|---|
| UI (benchmark client) | Socket | 295.78 | 3456.00 |
| Core | Shared memory + semaphores | 296.67 | 1806.67 |
| Logger | Pipe | 186.67 | 1718.67 |

Correct results in every run: standalone=3/3, multi=3/3. Errors: 0.00.
